// My Library Page

const currentUser = requireAuth();
let allUserBooks = [];
let currentBook = null;

async function loadLibrary() {
    try {
        const userBooks = await API.getUserBooks(currentUser.id);
        allUserBooks = userBooks.filter(b => b.status === 'owned');
        
        displayBooks(allUserBooks);
    } catch (error) {
        console.error('Error loading library:', error);
    }
}

function displayBooks(books) {
    const grid = document.getElementById('libraryGrid');
    const emptyState = document.getElementById('emptyState');
    
    if (books.length === 0) {
        grid.style.display = 'none';
        emptyState.style.display = 'block';
        return;
    }
    
    grid.style.display = 'grid';
    emptyState.style.display = 'none';
    
    grid.innerHTML = books.map(book => `
        <div class="gallery-card" onclick='openBookModal(${JSON.stringify(book).replace(/'/g, "&apos;")})'>
            <div class="card-image ${book.image_url ? '' : 'no-image'}">
                ${book.image_url ? 
                    `<img src="${book.image_url}" alt="${book.title}">` :
                    `<span class="no-image-text">No Image</span>`
                }
            </div>
            <div class="card-content">
                <div class="card-title">${book.title}</div>
                <div class="card-subtitle">by ${book.author}</div>
                <div class="card-info">
                    <span>${book.genre || 'Unknown Genre'}</span>
                    ${book.pages ? `<span>${book.pages} pages</span>` : ''}
                </div>
                <div class="card-badges">
                    <span class="badge owned">Owned</span>
                </div>
            </div>
        </div>
    `).join('');
}

// Search functionality
document.getElementById('searchInput').addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const filtered = allUserBooks.filter(book => 
        book.title.toLowerCase().includes(searchTerm) ||
        book.author.toLowerCase().includes(searchTerm) ||
        (book.genre && book.genre.toLowerCase().includes(searchTerm))
    );
    displayBooks(filtered);
});

// Modal functions
async function openBookModal(book) {
    currentBook = book;
    
    document.getElementById('modalTitle').textContent = book.title;
    document.getElementById('modalAuthor').textContent = book.author;
    document.getElementById('modalGenre').textContent = book.genre || 'Unknown';
    document.getElementById('modalPages').textContent = book.pages || 'Unknown';
    document.getElementById('modalStatus').textContent = 'Owned';
    
    // Set image
    const modalImage = document.getElementById('modalImage');
    if (book.image_url) {
        modalImage.innerHTML = `<img src="${book.image_url}" alt="${book.title}">`;
    } else {
        modalImage.innerHTML = '<span class="no-image-text">No Image</span>';
    }
    
    // Load personal notes by default
    await showNotes('personal');
    
    document.getElementById('bookModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('bookModal').style.display = 'none';
    currentBook = null;
}

async function showNotes(type) {
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    const notesContent = document.getElementById('notesContent');
    
    if (type === 'personal') {
        const notes = await API.getNotes('book', currentBook.id, currentUser.id);
        const personalNote = notes.find(n => !n.is_public);
        
        if (personalNote) {
            notesContent.innerHTML = `<p>${personalNote.content}</p>`;
        } else {
            notesContent.innerHTML = '<p style="color: var(--text-secondary);">No personal notes yet</p>';
        }
    } else {
        const publicNotes = await API.getPublicNotes('book', currentBook.id);
        
        if (publicNotes.length > 0) {
            notesContent.innerHTML = publicNotes.map(note => `
                <div style="margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid var(--border-color);">
                    <p>${note.content}</p>
                    <small style="color: var(--text-secondary);">- ${note.users?.username || 'Anonymous'}</small>
                </div>
            `).join('');
        } else {
            notesContent.innerHTML = '<p style="color: var(--text-secondary);">No public notes yet</p>';
        }
    }
}

function editNotes() {
    const content = prompt('Enter your note:');
    if (content) {
        const isPublic = confirm('Make this note public?');
        API.saveNote(currentUser.id, 'book', currentBook.id, content, isPublic);
        showNotes(isPublic ? 'public' : 'personal');
    }
}

function editBook() {
    window.location.href = `add-book.html?edit=${currentBook.id}`;
}

async function deleteBook() {
    if (confirm(`Are you sure you want to delete "${currentBook.title}"?`)) {
        // Delete from allBooks
        await API.deleteBook(currentBook.id);
        
        // Also remove from user's library
        const userId = currentUser.id;
        const userBooks = JSON.parse(localStorage.getItem(`userBooks_${userId}`) || '[]');
        const filteredBooks = userBooks.filter(b => b.id !== currentBook.id);
        localStorage.setItem(`userBooks_${userId}`, JSON.stringify(filteredBooks));
        
        alert('Book deleted successfully!');
        closeModal();
        loadLibrary();
    }
}

// Close modal on outside click
window.addEventListener('click', (e) => {
    if (e.target.id === 'bookModal') {
        closeModal();
    }
});

// Load on page load
loadLibrary();
