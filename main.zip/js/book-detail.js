// Book Detail Page

// Check authentication
const currentUser = requireAuth();
const userData = getUserData();

// Get book ID from URL
const urlParams = new URLSearchParams(window.location.search);
const bookId = parseInt(urlParams.get('id'));

// Find the book
const book = userData.books.find(b => b.id === bookId);

if (!book) {
    alert('Book not found');
    window.location.href = 'dashboard.html';
}

// Get user data
function getUserData() {
    const data = localStorage.getItem(`userData_${currentUser.id}`);
    return data ? JSON.parse(data) : { books: [], authors: {} };
}

function saveUserData(data) {
    localStorage.setItem(`userData_${currentUser.id}`, JSON.stringify(data));
}

// Dark mode
const darkModeToggle = document.getElementById('darkModeToggle');
const savedTheme = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', savedTheme);
darkModeToggle.textContent = savedTheme === 'dark' ? '☀️' : '🌙';

darkModeToggle.addEventListener('click', () => {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    darkModeToggle.textContent = newTheme === 'dark' ? '☀️' : '🌙';
});

// Display book details
function displayBookDetails() {
    document.getElementById('bookTitle').textContent = book.title;
    document.getElementById('bookAuthor').textContent = book.author;
    document.getElementById('bookAuthor').onclick = () => {
        window.location.href = `author-detail.html?name=${encodeURIComponent(book.author)}`;
    };
    document.getElementById('bookGenre').textContent = book.genre;
    document.getElementById('bookPages').textContent = `${book.totalPages} pages`;
    
    // Status
    const statusElement = document.getElementById('bookStatus');
    const statusText = book.status === 'want-to-read' ? 'Want to Read' 
                     : book.status === 'reading' ? 'Currently Reading' 
                     : 'Read';
    statusElement.textContent = statusText;
    statusElement.className = `value status-badge ${book.status}`;
    
    // Progress (only for currently reading)
    if (book.status === 'reading' && book.totalPages > 0) {
        const progress = Math.round((book.currentPage / book.totalPages) * 100);
        document.getElementById('progressItem').style.display = 'flex';
        document.getElementById('bookProgress').textContent = `${book.currentPage} / ${book.totalPages} pages (${progress}%)`;
    }
    
    // Rating (only for read books)
    if (book.rating && book.status === 'read') {
        const stars = '⭐'.repeat(Math.floor(book.rating)) + (book.rating % 1 ? '½' : '');
        document.getElementById('ratingItem').style.display = 'flex';
        document.getElementById('bookRating').textContent = `${stars} ${book.rating}/5`;
    }
    
    // Date finished
    if (book.dateFinished) {
        document.getElementById('dateItem').style.display = 'flex';
        const date = new Date(book.dateFinished);
        document.getElementById('bookDate').textContent = date.toLocaleDateString();
    }
    
    // Review
    const reviewElement = document.getElementById('bookReview');
    if (book.review) {
        reviewElement.innerHTML = `<p>${book.review.replace(/\n/g, '<br>')}</p>`;
    } else {
        reviewElement.innerHTML = '<p class="no-review">No review yet</p>';
    }
}

// Edit book
document.getElementById('editBookBtn').addEventListener('click', () => {
    // Store book ID in session for editing
    sessionStorage.setItem('editingBookId', bookId);
    window.location.href = 'dashboard.html';
});

// Delete book
document.getElementById('deleteBookBtn').addEventListener('click', () => {
    if (confirm(`Are you sure you want to delete "${book.title}"?`)) {
        const index = userData.books.findIndex(b => b.id === bookId);
        userData.books.splice(index, 1);
        saveUserData(userData);
        alert('Book deleted successfully');
        window.location.href = 'dashboard.html';
    }
});

function goBack() {
    window.location.href = 'dashboard.html';
}

// Initialize
displayBookDetails();
